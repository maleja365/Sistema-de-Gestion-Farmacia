package com.farmacia.controller;

import com.farmacia.model.Carrito;
import com.farmacia.model.Pedido;
import com.farmacia.service.CarritoService;
import com.farmacia.service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cliente/checkout")
public class CheckoutController {

    @Autowired
    private CarritoService carritoService;

    @Autowired
    private PedidoService pedidoService;

    /** Paso 1: Formulario de datos + método de pago */
    @GetMapping
    public String checkout(Model model, Authentication auth) {
        List<Carrito> items = carritoService.obtenerCarrito(auth.getName());
        if (items.isEmpty()) return "redirect:/cliente/carrito";

        model.addAttribute("usuario", auth.getName());
        model.addAttribute("items", items);
        model.addAttribute("total", carritoService.calcularTotal(items));
        return "checkout";
    }

    /** Paso 2: Confirmar pedido — el usuario revisa antes de pagar */
    @PostMapping("/confirmar")
    public String confirmar(@RequestParam String direccion,
                            @RequestParam String telefono,
                            @RequestParam(required = false, defaultValue = "") String notas,
                            @RequestParam String metodoPago,
                            Authentication auth,
                            Model model) {

        List<Carrito> items = carritoService.obtenerCarrito(auth.getName());
        if (items.isEmpty()) return "redirect:/cliente/carrito";

        double total = carritoService.calcularTotal(items);

        model.addAttribute("usuario", auth.getName());
        model.addAttribute("direccion", direccion);
        model.addAttribute("telefono", telefono);
        model.addAttribute("notas", notas);
        model.addAttribute("metodoPago", metodoPago);
        model.addAttribute("total", total);
        model.addAttribute("items", items);
        return "confirmar-pedido";  // Nueva vista de revisión
    }

    /** Paso 3: Procesar el pago según método elegido */
    @PostMapping("/pagar")
    public String pagar(@RequestParam String direccion,
                        @RequestParam String telefono,
                        @RequestParam(required = false, defaultValue = "") String notas,
                        @RequestParam String metodoPago,
                        Authentication auth,
                        Model model) {

        // Crear el pedido en BD
        Pedido pedido = pedidoService.crearPedido(auth.getName(), direccion, telefono, notas, metodoPago);

        model.addAttribute("usuario", auth.getName());
        model.addAttribute("pedido", pedido);
        model.addAttribute("metodoPago", metodoPago);

        // Redirigir a la pasarela según método
        switch (metodoPago) {
            case "EFECTIVO":
                return "pasarela/pasarela-efectivo";
            case "NEQUI":
                return "pasarela/pasarela-nequi";
            case "TARJETA":
                return "pasarela/pasarela-tarjeta";
            default:
                return "redirect:/cliente/inicio";
        }
    }

    /** Paso 4: Factura PDF — descarga */
    @GetMapping("/factura/{idPedido}")
    public void descargarFactura(@PathVariable Long idPedido,
                                  Authentication auth,
                                  jakarta.servlet.http.HttpServletResponse response) throws Exception {
        Pedido pedido = pedidoService.obtenerPedidoPorId(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        // Verificar que el pedido pertenece al usuario o es admin
        boolean esAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMINISTRADOR"));
        if (!esAdmin && !pedido.getUsuario().getUsuario().equals(auth.getName())) {
            response.sendError(403);
            return;
        }

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=factura-" + idPedido + ".pdf");

        com.farmacia.util.FacturaPdfGenerator.generar(pedido, response.getOutputStream());
    }
}
