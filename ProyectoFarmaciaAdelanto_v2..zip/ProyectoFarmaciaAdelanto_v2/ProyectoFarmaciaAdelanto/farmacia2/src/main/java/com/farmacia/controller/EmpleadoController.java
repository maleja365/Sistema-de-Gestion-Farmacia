package com.farmacia.controller;

import com.farmacia.model.Pedido;
import com.farmacia.model.Producto;
import com.farmacia.service.PedidoService;
import com.farmacia.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/empleado")
public class EmpleadoController {

    @Autowired private ProductoService productoService;
    @Autowired private PedidoService pedidoService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication auth) {
        List<Producto> todos = productoService.listarTodos();
        List<Producto> stockBajo = todos.stream()
            .filter(p -> p.getStock() < 5)
            .collect(Collectors.toList());
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("productos", todos);
        model.addAttribute("productosStockBajo", stockBajo);
        return "empleado/dashboard";
    }

    @GetMapping("/producto/buscar")
    public String buscarProducto(@RequestParam String nombre, Model model, Authentication auth) {
        List<Producto> todos = productoService.listarTodos();
        List<Producto> stockBajo = todos.stream()
            .filter(p -> p.getStock() < 5)
            .collect(Collectors.toList());
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("productos", productoService.buscarPorNombre(nombre));
        model.addAttribute("busqueda", nombre);
        model.addAttribute("productosStockBajo", stockBajo);
        return "empleado/dashboard";
    }

    @GetMapping("/producto/nuevo")
    public String nuevoProducto(Model model) {
        model.addAttribute("producto", new Producto());
        model.addAttribute("accion", "Crear");
        return "empleado/formulario-producto";
    }

    @PostMapping("/producto/guardar")
    public String guardarProducto(@ModelAttribute Producto producto) {
        productoService.guardar(producto);
        return "redirect:/empleado/dashboard";
    }

    @GetMapping("/producto/editar/{id}")
    public String editarProducto(@PathVariable Long id, Model model) {
        Producto producto = productoService.buscarPorId(id)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        model.addAttribute("producto", producto);
        model.addAttribute("accion", "Editar");
        return "empleado/formulario-producto";
    }

    @GetMapping("/producto/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id) {
        productoService.eliminar(id);
        return "redirect:/empleado/dashboard";
    }

    // ── Pedidos ──────────────────────────────────────────────────────────────

    @GetMapping("/pedidos")
    public String pedidos(Model model, Authentication auth) {
        List<Pedido> pedidos = pedidoService.obtenerTodosLosPedidos();
        long pendientes = pedidos.stream().filter(p -> "PENDIENTE".equals(p.getEstado())).count();
        long entregados = pedidos.stream().filter(p -> "ENTREGADO".equals(p.getEstado())).count();
        long cancelados = pedidos.stream().filter(p -> "CANCELADO".equals(p.getEstado())).count();
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("pedidos", pedidos);
        model.addAttribute("pendientes", pendientes);
        model.addAttribute("entregados", entregados);
        model.addAttribute("cancelados", cancelados);
        return "empleado/pedidos";
    }

    @GetMapping("/pedidos/detalle/{id}")
    public String detallePedido(@PathVariable Long id, Model model, Authentication auth) {
        Pedido pedido = pedidoService.obtenerPedidoPorId(id)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("pedido", pedido);
        return "empleado/detalle-pedido";
    }

    /** Marca como ENTREGADO y guarda quién lo gestionó */
    @PostMapping("/pedidos/completar/{id}")
    public String completarPedido(@PathVariable Long id, Authentication auth) {
        pedidoService.completarPedido(id, auth.getName());
        return "redirect:/empleado/pedidos";
    }

    /** Marca como CANCELADO, guarda motivo y quién lo gestionó */
    @PostMapping("/pedidos/cancelar/{id}")
    public String cancelarPedido(@PathVariable Long id,
                                  @RequestParam String motivo,
                                  Authentication auth) {
        pedidoService.cancelarPedido(id, motivo, auth.getName());
        return "redirect:/empleado/pedidos";
    }
}
