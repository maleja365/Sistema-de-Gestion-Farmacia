package com.farmacia.service;

import com.farmacia.model.Carrito;
import com.farmacia.model.Producto;
import com.farmacia.model.Usuario;
import com.farmacia.repository.CarritoRepository;
import com.farmacia.repository.ProductoRepository;
import com.farmacia.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ProductoRepository productoRepository;

    public List<Carrito> obtenerCarrito(String username) {
        Usuario usuario = usuarioRepository.findByUsuario(username).orElseThrow();
        return carritoRepository.findByUsuario(usuario);
    }

    public void agregarProducto(String username, Long idProducto) {
        Usuario usuario = usuarioRepository.findByUsuario(username).orElseThrow();
        Producto producto = productoRepository.findById(idProducto).orElseThrow();

        Optional<Carrito> existente = carritoRepository
            .findByUsuarioAndProducto_IdProducto(usuario, idProducto);

        if (existente.isPresent()) {
            Carrito item = existente.get();
            item.setCantidad(item.getCantidad() + 1);
            carritoRepository.save(item);
        } else {
            Carrito item = new Carrito();
            item.setUsuario(usuario);
            item.setProducto(producto);
            item.setCantidad(1);
            carritoRepository.save(item);
        }
    }

    public void aumentarCantidad(Long idCarrito) {
        Carrito item = carritoRepository.findById(idCarrito).orElseThrow();
        item.setCantidad(item.getCantidad() + 1);
        carritoRepository.save(item);
    }

    public void reducirCantidad(Long idCarrito) {
        Carrito item = carritoRepository.findById(idCarrito).orElseThrow();
        if (item.getCantidad() <= 1) {
            carritoRepository.delete(item);
        } else {
            item.setCantidad(item.getCantidad() - 1);
            carritoRepository.save(item);
        }
    }

    public void eliminarItem(Long idCarrito) {
        carritoRepository.deleteById(idCarrito);
    }

    @Transactional
    public void vaciarCarrito(String username) {
        Usuario usuario = usuarioRepository.findByUsuario(username).orElseThrow();
        carritoRepository.deleteByUsuario(usuario);
    }

    public double calcularTotal(List<Carrito> items) {
        return items.stream().mapToDouble(Carrito::getSubtotal).sum();
    }
}