package com.farmacia.model;

import jakarta.persistence.*;

@Entity
@Table(name = "detalle_pedido")
public class DetallePedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDetalle;

    @ManyToOne
    @JoinColumn(name = "id_pedido")
    private Pedido pedido;

    private String nombreProducto;
    private Integer cantidad;
    private Double precioUnitario;
    private Double subtotal;

    // Getters
    public Long getIdDetalle()         { return idDetalle; }
    public Pedido getPedido()          { return pedido; }
    public String getNombreProducto()  { return nombreProducto; }
    public Integer getCantidad()       { return cantidad; }
    public Double getPrecioUnitario()  { return precioUnitario; }
    public Double getSubtotal()        { return subtotal; }

    // Setters
    public void setIdDetalle(Long idDetalle)             { this.idDetalle = idDetalle; }
    public void setPedido(Pedido pedido)                 { this.pedido = pedido; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }
    public void setCantidad(Integer cantidad)            { this.cantidad = cantidad; }
    public void setPrecioUnitario(Double precioUnitario) { this.precioUnitario = precioUnitario; }
    public void setSubtotal(Double subtotal)             { this.subtotal = subtotal; }
}
