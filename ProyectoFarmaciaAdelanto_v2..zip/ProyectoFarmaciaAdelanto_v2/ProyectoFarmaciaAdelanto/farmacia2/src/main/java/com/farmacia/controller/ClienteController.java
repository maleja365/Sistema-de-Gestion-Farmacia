package com.farmacia.controller;

import com.farmacia.model.Carrito;
import com.farmacia.service.CarritoService;
import com.farmacia.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private CarritoService carritoService;

    @GetMapping("/inicio")
    public String inicio(Model model, Authentication auth) {
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("productos", productoService.listarTodos());
        List<Carrito> carrito = carritoService.obtenerCarrito(auth.getName());
        model.addAttribute("cantidadCarrito", carrito.size());
        return "dashboard-cliente";
    }

    @GetMapping("/carrito")
    public String verCarrito(Model model, Authentication auth) {
        model.addAttribute("usuario", auth.getName());
        List<Carrito> items = carritoService.obtenerCarrito(auth.getName());
        model.addAttribute("items", items);
        model.addAttribute("total", carritoService.calcularTotal(items));
        return "carrito";
    }
}