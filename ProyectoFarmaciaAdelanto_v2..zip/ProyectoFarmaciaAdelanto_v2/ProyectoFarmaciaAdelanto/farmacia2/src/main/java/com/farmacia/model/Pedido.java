package com.farmacia.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPedido;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    private String direccion;
    private String telefono;
    private String notas;
    private String metodoPago;
    private Double total;
    private String estado;

    @Column(columnDefinition = "TEXT")
    private String motivoCancelacion;

    private LocalDateTime fechaPedido;

    /** Usuario (empleado) que marcó el pedido como ENTREGADO o CANCELADO */
    private String gestionadoPor;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<DetallePedido> detalles;

    @PrePersist
    public void prePersist() {
        fechaPedido = LocalDateTime.now();
        if (estado == null) estado = "PENDIENTE";
    }

    public Long getIdPedido()               { return idPedido; }
    public Usuario getUsuario()             { return usuario; }
    public String getDireccion()            { return direccion; }
    public String getTelefono()             { return telefono; }
    public String getNotas()                { return notas; }
    public String getMetodoPago()           { return metodoPago; }
    public Double getTotal()                { return total; }
    public String getEstado()               { return estado; }
    public String getMotivoCancelacion()    { return motivoCancelacion; }
    public LocalDateTime getFechaPedido()   { return fechaPedido; }
    public String getGestionadoPor()        { return gestionadoPor; }
    public List<DetallePedido> getDetalles(){ return detalles; }

    public void setIdPedido(Long idPedido)                   { this.idPedido = idPedido; }
    public void setUsuario(Usuario usuario)                   { this.usuario = usuario; }
    public void setDireccion(String direccion)                { this.direccion = direccion; }
    public void setTelefono(String telefono)                  { this.telefono = telefono; }
    public void setNotas(String notas)                        { this.notas = notas; }
    public void setMetodoPago(String metodoPago)              { this.metodoPago = metodoPago; }
    public void setTotal(Double total)                        { this.total = total; }
    public void setEstado(String estado)                      { this.estado = estado; }
    public void setMotivoCancelacion(String motivo)           { this.motivoCancelacion = motivo; }
    public void setFechaPedido(LocalDateTime f)               { this.fechaPedido = f; }
    public void setGestionadoPor(String gestionadoPor)        { this.gestionadoPor = gestionadoPor; }
    public void setDetalles(List<DetallePedido> d)            { this.detalles = d; }
}
