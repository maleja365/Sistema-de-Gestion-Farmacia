package com.farmacia.controller;

import com.farmacia.model.Pedido;
import com.farmacia.model.Usuario;
import com.farmacia.repository.UsuarioRepository;
import com.farmacia.service.PedidoService;
import com.farmacia.util.ReportePdfGenerator;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private PedidoService pedidoService;

    // ─── DASHBOARD ───────────────────────────────────────────────────────────

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) String busqueda,
                            Model model, Authentication auth) {
        model.addAttribute("usuario", auth.getName());

        List<Usuario> empleados = usuarioRepository.findByRol("EMPLEADO");
        List<Usuario> clientes  = usuarioRepository.findByRol("CLIENTE");

        // Filtrar si hay búsqueda
        if (busqueda != null && !busqueda.isBlank()) {
            String q = busqueda.toLowerCase();
            empleados = empleados.stream()
                .filter(e -> e.getNombre().toLowerCase().contains(q)
                          || e.getUsuario().toLowerCase().contains(q))
                .toList();
            clientes = clientes.stream()
                .filter(c -> c.getNombre().toLowerCase().contains(q)
                          || c.getUsuario().toLowerCase().contains(q))
                .toList();
            model.addAttribute("busqueda", busqueda);
        }

        model.addAttribute("empleados", empleados);
        model.addAttribute("clientes",  clientes);
        model.addAttribute("totalEmpleados", usuarioRepository.findByRol("EMPLEADO").size());
        model.addAttribute("totalClientes",  usuarioRepository.findByRol("CLIENTE").size());
        return "admin/dashboard";
    }

    // ─── CRUD EMPLEADOS ───────────────────────────────────────────────────────

    @GetMapping("/empleado/nuevo")
    public String nuevoEmpleado(Model model, Authentication auth) {
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("empleado", new Usuario());
        model.addAttribute("accion", "Crear");
        return "admin/formulario-empleado";
    }

    @PostMapping("/empleado/guardar")
    public String guardarEmpleado(@ModelAttribute("empleado") Usuario empleado,
                                  @RequestParam(required = false) Long id,
                                  Model model, Authentication auth) {
        var existente = usuarioRepository.findByUsuario(empleado.getUsuario());
        if (existente.isPresent() && !existente.get().getIdUsuario().equals(id)) {
            model.addAttribute("usuario", auth.getName());
            model.addAttribute("empleado", empleado);
            model.addAttribute("accion", id == null ? "Crear" : "Editar");
            model.addAttribute("error", "El nombre de usuario ya está en uso.");
            return "admin/formulario-empleado";
        }
        if (id != null) {
            Usuario actual = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
            actual.setNombre(empleado.getNombre());
            actual.setUsuario(empleado.getUsuario());
            if (empleado.getContrasena() != null && !empleado.getContrasena().isBlank()) {
                actual.setContrasena(empleado.getContrasena());
            }
            actual.setRol("EMPLEADO");
            usuarioRepository.save(actual);
        } else {
            empleado.setRol("EMPLEADO");
            usuarioRepository.save(empleado);
        }
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/empleado/editar/{id}")
    public String editarEmpleado(@PathVariable Long id, Model model, Authentication auth) {
        Usuario empleado = usuarioRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("empleado", empleado);
        model.addAttribute("accion", "Editar");
        return "admin/formulario-empleado";
    }

    @GetMapping("/empleado/eliminar/{id}")
    public String eliminarEmpleado(@PathVariable Long id) {
        usuarioRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/empleado/detalle/{id}")
    public String detalleEmpleado(@PathVariable Long id, Model model, Authentication auth) {
        Usuario empleado = usuarioRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("perfil", empleado);
        model.addAttribute("tipo", "Empleado");
        return "admin/detalle-usuario";
    }

    // ─── GESTIÓN CLIENTES ─────────────────────────────────────────────────────

    @GetMapping("/cliente/detalle/{id}")
    public String detalleCliente(@PathVariable Long id, Model model, Authentication auth) {
        Usuario cliente = usuarioRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("perfil", cliente);
        model.addAttribute("tipo", "Cliente");
        return "admin/detalle-usuario";
    }

    @GetMapping("/cliente/eliminar/{id}")
    public String eliminarCliente(@PathVariable Long id) {
        usuarioRepository.deleteById(id);
        return "redirect:/admin/dashboard";
    }

    // ─── REPORTE DE VENTAS ────────────────────────────────────────────────────

    /** Muestra el reporte de ventas del día seleccionado */
    @GetMapping("/reporte")
    public String reporte(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            Model model, Authentication auth) {

        model.addAttribute("usuario", auth.getName());

        if (fecha == null) fecha = LocalDate.now();
        model.addAttribute("fecha", fecha);

        List<Pedido> pedidos = pedidoService.obtenerPedidosPorFecha(fecha);
        double totalDia = pedidoService.calcularTotalVentas(pedidos);

        long entregados = pedidos.stream().filter(p -> "ENTREGADO".equals(p.getEstado())).count();
        long cancelados = pedidos.stream().filter(p -> "CANCELADO".equals(p.getEstado())).count();
        long pendientes = pedidos.stream().filter(p -> "PENDIENTE".equals(p.getEstado())).count();

        model.addAttribute("pedidos", pedidos);
        model.addAttribute("totalDia", totalDia);
        model.addAttribute("entregados", entregados);
        model.addAttribute("cancelados", cancelados);
        model.addAttribute("pendientes", pendientes);
        return "admin/reporte-ventas";
    }

    /** Descarga el reporte del día como PDF */
    @GetMapping("/reporte/pdf")
    public void reportePdf(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            HttpServletResponse response) throws Exception {

        if (fecha == null) fecha = LocalDate.now();

        List<Pedido> pedidos = pedidoService.obtenerPedidosPorFecha(fecha);
        double totalDia = pedidoService.calcularTotalVentas(pedidos);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition",
                "attachment; filename=\"reporte-ventas-" + fecha + ".pdf\"");

        ReportePdfGenerator.generar(fecha, pedidos, totalDia, response.getOutputStream());
        response.getOutputStream().flush();
    }
}
