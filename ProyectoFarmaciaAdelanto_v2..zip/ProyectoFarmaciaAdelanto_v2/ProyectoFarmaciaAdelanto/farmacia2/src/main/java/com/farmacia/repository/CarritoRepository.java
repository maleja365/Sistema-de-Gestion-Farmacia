package com.farmacia.repository;

import com.farmacia.model.Carrito;
import com.farmacia.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    List<Carrito> findByUsuario(Usuario usuario);
    Optional<Carrito> findByUsuarioAndProducto_IdProducto(Usuario usuario, Long idProducto);
    void deleteByUsuario(Usuario usuario);
}