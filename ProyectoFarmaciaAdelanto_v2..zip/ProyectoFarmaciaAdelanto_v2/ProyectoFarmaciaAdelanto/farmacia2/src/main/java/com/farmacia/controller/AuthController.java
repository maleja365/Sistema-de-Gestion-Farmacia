package com.farmacia.controller;

import com.farmacia.model.Usuario;
import com.farmacia.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String inicio() {
        return "redirect:/login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("nuevoUsuario", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(@ModelAttribute("nuevoUsuario") Usuario usuario, Model model) {
        if (usuarioRepository.findByUsuario(usuario.getUsuario()).isPresent()) {
            model.addAttribute("error", "El nombre de usuario ya está en uso.");
            model.addAttribute("nuevoUsuario", usuario);
            return "registro";
        }
        usuario.setRol("CLIENTE");
        usuarioRepository.save(usuario);
        return "redirect:/login?registrado";
    }
}