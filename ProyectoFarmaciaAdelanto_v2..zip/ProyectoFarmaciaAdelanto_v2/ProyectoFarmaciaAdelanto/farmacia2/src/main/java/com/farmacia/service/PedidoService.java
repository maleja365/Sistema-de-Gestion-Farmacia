package com.farmacia.service;

import com.farmacia.model.*;
import com.farmacia.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PedidoService {

    @Autowired private PedidoRepository pedidoRepository;
    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private CarritoService carritoService;

    @Transactional
    public Pedido crearPedido(String username, String direccion, String telefono,
                               String notas, String metodoPago) {
        Usuario usuario = usuarioRepository.findByUsuario(username).orElseThrow();
        List<Carrito> items = carritoService.obtenerCarrito(username);
        double total = carritoService.calcularTotal(items);

        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setDireccion(direccion);
        pedido.setTelefono(telefono);
        pedido.setNotas(notas);
        pedido.setMetodoPago(metodoPago);
        pedido.setTotal(total);

        List<DetallePedido> detalles = new ArrayList<>();
        for (Carrito item : items) {
            DetallePedido d = new DetallePedido();
            d.setPedido(pedido);
            d.setNombreProducto(item.getProducto().getNombre());
            d.setCantidad(item.getCantidad());
            d.setPrecioUnitario(item.getProducto().getPrecio());
            d.setSubtotal(item.getSubtotal());
            detalles.add(d);
        }
        pedido.setDetalles(detalles);

        Pedido guardado = pedidoRepository.save(pedido);
        carritoService.vaciarCarrito(username);
        return guardado;
    }

    public List<Pedido> obtenerPedidosUsuario(String username) {
        Usuario usuario = usuarioRepository.findByUsuario(username).orElseThrow();
        return pedidoRepository.findByUsuarioOrderByFechaPedidoDesc(usuario);
    }

    public Optional<Pedido> obtenerPedidoPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    public List<Pedido> obtenerTodosLosPedidos() {
        return pedidoRepository.findAllByOrderByFechaPedidoDesc();
    }

    /** Pedidos del día indicado (de 00:00:00 a 23:59:59) */
    public List<Pedido> obtenerPedidosPorFecha(LocalDate fecha) {
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin    = fecha.atTime(23, 59, 59);
        return pedidoRepository.findByFechaPedidoBetween(inicio, fin);
    }

    /** Total de ventas (sólo ENTREGADOS) de una lista de pedidos */
    public double calcularTotalVentas(List<Pedido> pedidos) {
        return pedidos.stream()
                .filter(p -> "ENTREGADO".equals(p.getEstado()))
                .mapToDouble(Pedido::getTotal)
                .sum();
    }

    // ── Ahora reciben el username del empleado que gestiona ──────────────────

    @Transactional
    public void completarPedido(Long id, String empleadoUsername) {
        Pedido pedido = pedidoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        pedido.setEstado("ENTREGADO");
        pedido.setGestionadoPor(empleadoUsername);
        pedidoRepository.save(pedido);
    }

    @Transactional
    public void cancelarPedido(Long id, String motivo, String empleadoUsername) {
        Pedido pedido = pedidoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
        pedido.setEstado("CANCELADO");
        pedido.setMotivoCancelacion(motivo);
        pedido.setGestionadoPor(empleadoUsername);
        pedidoRepository.save(pedido);
    }
}
