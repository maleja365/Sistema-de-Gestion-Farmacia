package com.farmacia.controller;

import com.farmacia.service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cliente/carrito")
public class CarritoController {

    @Autowired
    private CarritoService carritoService;

    @PostMapping("/agregar/{idProducto}")
    public String agregar(@PathVariable Long idProducto, Authentication auth) {
        carritoService.agregarProducto(auth.getName(), idProducto);
        return "redirect:/cliente/inicio";
    }

    @PostMapping("/aumentar/{idCarrito}")
    public String aumentar(@PathVariable Long idCarrito) {
        carritoService.aumentarCantidad(idCarrito);
        return "redirect:/cliente/carrito";
    }

    @PostMapping("/reducir/{idCarrito}")
    public String reducir(@PathVariable Long idCarrito) {
        carritoService.reducirCantidad(idCarrito);
        return "redirect:/cliente/carrito";
    }

    @PostMapping("/eliminar/{idCarrito}")
    public String eliminar(@PathVariable Long idCarrito) {
        carritoService.eliminarItem(idCarrito);
        return "redirect:/cliente/carrito";
    }

    @PostMapping("/vaciar")
    public String vaciar(Authentication auth) {
        carritoService.vaciarCarrito(auth.getName());
        return "redirect:/cliente/carrito";
    }
}