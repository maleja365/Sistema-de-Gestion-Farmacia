package com.farmacia.model;

import jakarta.persistence.*;

@Entity
@Table(name = "carrito")
public class Carrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCarrito;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "id_producto")
    private Producto producto;

    private int cantidad;

    public Long getIdCarrito() { return idCarrito; }
    public Usuario getUsuario() { return usuario; }
    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }

    public void setIdCarrito(Long idCarrito) { this.idCarrito = idCarrito; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public void setProducto(Producto producto) { this.producto = producto; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public double getSubtotal() {
        return producto.getPrecio() * cantidad;
    }
}