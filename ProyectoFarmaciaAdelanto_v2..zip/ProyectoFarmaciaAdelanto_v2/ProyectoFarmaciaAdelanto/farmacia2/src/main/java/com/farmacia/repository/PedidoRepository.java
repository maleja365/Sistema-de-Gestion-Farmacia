package com.farmacia.repository;

import com.farmacia.model.Pedido;
import com.farmacia.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByUsuarioOrderByFechaPedidoDesc(Usuario usuario);

    List<Pedido> findAllByOrderByFechaPedidoDesc();

    /** Todos los pedidos entre dos fechas, ordenados por fecha ascendente */
    @Query("SELECT p FROM Pedido p WHERE p.fechaPedido BETWEEN :inicio AND :fin ORDER BY p.fechaPedido ASC")
    List<Pedido> findByFechaPedidoBetween(@Param("inicio") LocalDateTime inicio,
                                           @Param("fin")   LocalDateTime fin);
}
