package com.farmacia.controller;

import com.farmacia.model.Pedido;
import com.farmacia.service.PedidoService;
import com.farmacia.util.FacturaPdfGenerator;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/cliente")
public class HistorialController {

    @Autowired
    private PedidoService pedidoService;

    // GET /cliente/historial
    @GetMapping("/historial")
    public String historial(Authentication auth, Model model) {
        List<Pedido> pedidos = pedidoService.obtenerPedidosUsuario(auth.getName());
        model.addAttribute("usuario", auth.getName());
        model.addAttribute("pedidos", pedidos);
        return "historial-compras";
    }

    // GET /cliente/pedido/{id}/factura
    @Transactional(readOnly = true)
    @GetMapping("/pedido/{id}/factura")
    public void descargarFactura(@PathVariable Long id,
                                 Authentication auth,
                                 HttpServletResponse response) throws Exception {

        Optional<Pedido> opt = pedidoService.obtenerPedidoPorId(id);

        // Pedido no existe
        if (opt.isEmpty()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Pedido no encontrado");
            return;
        }

        Pedido pedido = opt.get();

        // Seguridad: el pedido debe pertenecer al usuario autenticado
        if (!pedido.getUsuario().getUsuario().equals(auth.getName())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Acceso denegado");
            return;
        }

        // Forzar inicialización de detalles (por si son LAZY)
        pedido.getDetalles().size();

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition",
                "attachment; filename=\"factura-" + String.format("%06d", id) + ".pdf\"");

        FacturaPdfGenerator.generar(pedido, response.getOutputStream());
        response.getOutputStream().flush();
    }
}