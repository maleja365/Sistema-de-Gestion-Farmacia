package com.farmacia.util;

import com.farmacia.model.DetallePedido;
import com.farmacia.model.Pedido;

import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Genera el reporte de ventas diario en PDF con el estilo visual de FarmaciApp.
 * Usa OpenPDF (com.lowagie).
 */
public class ReportePdfGenerator {

    private static final DateTimeFormatter FMT_FECHA   = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FMT_HORA    = DateTimeFormatter.ofPattern("HH:mm");

    // ── Paleta FarmaciApp ─────────────────────────────────────────────────────
    private static final java.awt.Color CIAN        = new java.awt.Color(0,   86,  168);
    private static final java.awt.Color CIAN_DARK   = new java.awt.Color(0,   64,  128);
    private static final java.awt.Color VERDE       = new java.awt.Color(106, 222,  29);
    private static final java.awt.Color VERDE_DARK  = new java.awt.Color(40,  128,  84);
    private static final java.awt.Color BG          = new java.awt.Color(240, 244, 248);
    private static final java.awt.Color CARD_BORDER = new java.awt.Color(228, 236, 245);
    private static final java.awt.Color ROW_ALT     = new java.awt.Color(245, 247, 250);
    private static final java.awt.Color TEXT_DARK   = new java.awt.Color(26,  42,   58);
    private static final java.awt.Color TEXT_GREY   = new java.awt.Color(136, 136, 136);
    private static final java.awt.Color NARANJA_BG  = new java.awt.Color(255, 243, 224);
    private static final java.awt.Color NARANJA_FG  = new java.awt.Color(230,  81,   0);
    private static final java.awt.Color ROJO_BG     = new java.awt.Color(252, 228, 228);
    private static final java.awt.Color ROJO_FG     = new java.awt.Color(192,  57,  43);

    public static void generar(LocalDate fecha,
                               java.util.List<Pedido> pedidos,
                               double totalDia,
                               OutputStream out) throws Exception {

        com.lowagie.text.Document doc =
                new com.lowagie.text.Document(com.lowagie.text.PageSize.A4, 36, 36, 36, 36);
        com.lowagie.text.pdf.PdfWriter writer =
                com.lowagie.text.pdf.PdfWriter.getInstance(doc, out);
        doc.open();

        com.lowagie.text.pdf.PdfContentByte canvas = writer.getDirectContentUnder();
        float pageW = doc.getPageSize().getWidth();
        float pageH = doc.getPageSize().getHeight();

        // Fondo general
        canvas.setColorFill(BG);
        canvas.rectangle(0, 0, pageW, pageH);
        canvas.fill();

        // Banda navbar cian
        canvas.setColorFill(CIAN);
        canvas.rectangle(0, pageH - 78, pageW, 78);
        canvas.fill();

        // Franja verde
        canvas.setColorFill(VERDE);
        canvas.rectangle(0, pageH - 82, pageW, 4);
        canvas.fill();

        // ── Logo ──
        com.lowagie.text.Paragraph logo = new com.lowagie.text.Paragraph();
        logo.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        logo.add(new com.lowagie.text.Chunk("Farmaci",
                font(24, com.lowagie.text.Font.BOLD, java.awt.Color.WHITE)));
        logo.add(new com.lowagie.text.Chunk("App",
                font(24, com.lowagie.text.Font.BOLD, VERDE)));
        logo.add(new com.lowagie.text.Chunk("  —  Reporte de Ventas",
                font(12, com.lowagie.text.Font.NORMAL,
                        new java.awt.Color(255,255,255,180))));
        logo.setSpacingBefore(16);
        logo.setSpacingAfter(4);
        doc.add(logo);

        com.lowagie.text.Paragraph sub = new com.lowagie.text.Paragraph(
                "Farmacia Adelanto  ·  Generado el " +
                LocalDate.now().format(FMT_FECHA),
                font(9, com.lowagie.text.Font.NORMAL,
                        new java.awt.Color(255,255,255,190)));
        sub.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        doc.add(sub);

        espacio(doc, 18);

        // ── Cabecera del reporte (fecha seleccionada) ──
        com.lowagie.text.pdf.PdfPTable cardFecha = tabla1Col();
        com.lowagie.text.Phrase phrFecha = new com.lowagie.text.Phrase();
        phrFecha.add(new com.lowagie.text.Chunk("REPORTE DEL DÍA:  ",
                font(9, com.lowagie.text.Font.BOLD, CIAN)));
        phrFecha.add(new com.lowagie.text.Chunk(fecha.format(FMT_FECHA),
                font(13, com.lowagie.text.Font.BOLD, TEXT_DARK)));
        com.lowagie.text.pdf.PdfPCell cFecha = celda(phrFecha,
                com.lowagie.text.Element.ALIGN_CENTER);
        cFecha.setBackgroundColor(java.awt.Color.WHITE);
        cardFecha.addCell(cFecha);
        doc.add(cardFecha);

        espacio(doc, 10);

        // ── Stats del día (3 columnas) ──
        long entregados = pedidos.stream().filter(p -> "ENTREGADO".equals(p.getEstado())).count();
        long cancelados = pedidos.stream().filter(p -> "CANCELADO".equals(p.getEstado())).count();
        long pendientes = pedidos.stream().filter(p -> "PENDIENTE".equals(p.getEstado())).count();

        com.lowagie.text.pdf.PdfPTable stats = new com.lowagie.text.pdf.PdfPTable(4);
        stats.setWidthPercentage(100);
        stats.setWidths(new float[]{28f, 24f, 24f, 24f});

        // Stat total
        stats.addCell(statCell("TOTAL VENTAS (ENTREGADOS)",
                formatPrecio(totalDia), CIAN, java.awt.Color.WHITE, CIAN));
        stats.addCell(statCell("ENTREGADOS",
                String.valueOf(entregados), VERDE_DARK,
                new java.awt.Color(232,245,233), new java.awt.Color(200,230,200)));
        stats.addCell(statCell("CANCELADOS",
                String.valueOf(cancelados), ROJO_FG, ROJO_BG,
                new java.awt.Color(240,200,200)));
        stats.addCell(statCell("PENDIENTES",
                String.valueOf(pendientes), NARANJA_FG, NARANJA_BG,
                new java.awt.Color(255,220,180)));
        doc.add(stats);

        espacio(doc, 12);

        // ── Tabla de pedidos ──
        com.lowagie.text.Paragraph lblPedidos = new com.lowagie.text.Paragraph(
                "📋  DETALLE DE PEDIDOS",
                font(9, com.lowagie.text.Font.BOLD, CIAN));
        lblPedidos.setSpacingAfter(6);
        doc.add(lblPedidos);

        if (pedidos.isEmpty()) {
            com.lowagie.text.Paragraph sinPed = new com.lowagie.text.Paragraph(
                    "No hay pedidos para esta fecha.",
                    font(11, com.lowagie.text.Font.ITALIC, TEXT_GREY));
            sinPed.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
            sinPed.setSpacingBefore(20);
            doc.add(sinPed);
        } else {
            // Cabecera tabla
            float[] ws = {8f, 12f, 18f, 15f, 14f, 14f, 19f};
            com.lowagie.text.pdf.PdfPTable tbl =
                    new com.lowagie.text.pdf.PdfPTable(ws);
            tbl.setWidthPercentage(100);

            String[] heads = {"#", "Hora", "Cliente", "Dirección", "Método", "Estado", "Gestionado por"};
            for (String h : heads) {
                com.lowagie.text.pdf.PdfPCell c =
                        new com.lowagie.text.pdf.PdfPCell(
                                new com.lowagie.text.Phrase(h,
                                        font(9, com.lowagie.text.Font.BOLD,
                                                java.awt.Color.WHITE)));
                c.setBackgroundColor(CIAN);
                c.setPadding(7); c.setBorder(0);
                tbl.addCell(c);
            }

            boolean alt = false;
            for (Pedido p : pedidos) {
                java.awt.Color bg = alt ? ROW_ALT : java.awt.Color.WHITE;

                // Color de estado
                java.awt.Color estadoColor = switch (p.getEstado()) {
                    case "ENTREGADO" -> VERDE_DARK;
                    case "CANCELADO" -> ROJO_FG;
                    default          -> NARANJA_FG;
                };

                fila(tbl, String.format("%06d", p.getIdPedido()),
                        font(9, com.lowagie.text.Font.NORMAL, TEXT_DARK),
                        bg, com.lowagie.text.Element.ALIGN_LEFT);
                fila(tbl, p.getFechaPedido().format(FMT_HORA),
                        font(9, com.lowagie.text.Font.NORMAL, TEXT_DARK),
                        bg, com.lowagie.text.Element.ALIGN_CENTER);
                fila(tbl, p.getUsuario().getNombre(),
                        font(9, com.lowagie.text.Font.NORMAL, TEXT_DARK),
                        bg, com.lowagie.text.Element.ALIGN_LEFT);
                fila(tbl, p.getDireccion() != null ? p.getDireccion() : "—",
                        font(9, com.lowagie.text.Font.NORMAL, TEXT_DARK),
                        bg, com.lowagie.text.Element.ALIGN_LEFT);
                fila(tbl, p.getMetodoPago() != null ? p.getMetodoPago() : "—",
                        font(9, com.lowagie.text.Font.NORMAL, TEXT_DARK),
                        bg, com.lowagie.text.Element.ALIGN_CENTER);
                fila(tbl, p.getEstado(),
                        font(9, com.lowagie.text.Font.BOLD, estadoColor),
                        bg, com.lowagie.text.Element.ALIGN_CENTER);
                fila(tbl, p.getGestionadoPor() != null ? p.getGestionadoPor() : "—",
                        font(9, com.lowagie.text.Font.ITALIC, TEXT_GREY),
                        bg, com.lowagie.text.Element.ALIGN_LEFT);
                alt = !alt;

                // Sub-tabla productos (colapsada, solo si tiene detalles)
                if (p.getDetalles() != null && !p.getDetalles().isEmpty()) {
                    // Fila expandida con detalles de productos
                    com.lowagie.text.pdf.PdfPCell cDetalle =
                            new com.lowagie.text.pdf.PdfPCell();
                    cDetalle.setColspan(7);
                    cDetalle.setBackgroundColor(new java.awt.Color(248, 250, 253));
                    cDetalle.setBorderColor(CARD_BORDER);
                    cDetalle.setPaddingLeft(20);
                    cDetalle.setPaddingTop(4);
                    cDetalle.setPaddingBottom(6);

                    StringBuilder sb = new StringBuilder();
                    for (DetallePedido d : p.getDetalles()) {
                        sb.append(d.getNombreProducto())
                          .append(" × ").append(d.getCantidad())
                          .append("   ").append(formatPrecio(d.getSubtotal()))
                          .append("     ");
                    }
                    sb.append("   ").append("Total: ").append(formatPrecio(p.getTotal()));

                    com.lowagie.text.Phrase phrDet = new com.lowagie.text.Phrase(
                            sb.toString(),
                            font(8, com.lowagie.text.Font.NORMAL, TEXT_GREY));
                    cDetalle.setPhrase(phrDet);
                    tbl.addCell(cDetalle);
                }
            }
            doc.add(tbl);

            // ── Total final ──
            espacio(doc, 10);
            com.lowagie.text.pdf.PdfPTable cardTotal = tabla1Col();
            com.lowagie.text.Phrase phrTotal = new com.lowagie.text.Phrase();
            phrTotal.add(new com.lowagie.text.Chunk("TOTAL DE VENTAS DEL DÍA (entregados):   ",
                    font(10, com.lowagie.text.Font.BOLD, CIAN)));
            phrTotal.add(new com.lowagie.text.Chunk(formatPrecio(totalDia),
                    font(14, com.lowagie.text.Font.BOLD, VERDE_DARK)));
            com.lowagie.text.pdf.PdfPCell cTotal = celda(phrTotal,
                    com.lowagie.text.Element.ALIGN_RIGHT);
            cTotal.setBackgroundColor(java.awt.Color.WHITE);
            cardTotal.addCell(cTotal);
            doc.add(cardTotal);
        }

        // ── Footer ──
        espacio(doc, 14);
        com.lowagie.text.pdf.draw.LineSeparator sep =
                new com.lowagie.text.pdf.draw.LineSeparator(
                        1.5f, 100f, CIAN, com.lowagie.text.Element.ALIGN_CENTER, -2);
        doc.add(new com.lowagie.text.Chunk(sep));
        com.lowagie.text.pdf.draw.LineSeparator sepV =
                new com.lowagie.text.pdf.draw.LineSeparator(
                        3f, 100f, VERDE, com.lowagie.text.Element.ALIGN_CENTER, -4);
        doc.add(new com.lowagie.text.Chunk(sepV));
        espacio(doc, 6);
        com.lowagie.text.Paragraph footer = new com.lowagie.text.Paragraph(
                "Documento generado automáticamente por FarmaciApp — uso interno",
                font(8, com.lowagie.text.Font.ITALIC, TEXT_GREY));
        footer.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        doc.add(footer);

        doc.close();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static com.lowagie.text.Font font(float size, int style, java.awt.Color color) {
        return new com.lowagie.text.Font(
                com.lowagie.text.Font.HELVETICA, size, style, color);
    }

    private static void espacio(com.lowagie.text.Document doc, float pts) throws Exception {
        com.lowagie.text.Paragraph sp = new com.lowagie.text.Paragraph(" ");
        sp.setSpacingAfter(pts);
        doc.add(sp);
    }

    private static com.lowagie.text.pdf.PdfPTable tabla1Col() throws Exception {
        com.lowagie.text.pdf.PdfPTable t =
                new com.lowagie.text.pdf.PdfPTable(1);
        t.setWidthPercentage(100);
        return t;
    }

    private static com.lowagie.text.pdf.PdfPCell celda(
            com.lowagie.text.Phrase p, int align) {
        com.lowagie.text.pdf.PdfPCell c =
                new com.lowagie.text.pdf.PdfPCell(p);
        c.setBackgroundColor(java.awt.Color.WHITE);
        c.setBorderColor(CARD_BORDER);
        c.setBorderWidth(1.5f);
        c.setPadding(11);
        c.setHorizontalAlignment(align);
        c.setVerticalAlignment(com.lowagie.text.Element.ALIGN_MIDDLE);
        return c;
    }

    private static void fila(com.lowagie.text.pdf.PdfPTable tbl,
                              String texto,
                              com.lowagie.text.Font font,
                              java.awt.Color bg, int align) {
        com.lowagie.text.pdf.PdfPCell c =
                new com.lowagie.text.pdf.PdfPCell(
                        new com.lowagie.text.Phrase(texto, font));
        c.setBackgroundColor(bg);
        c.setPadding(6);
        c.setBorderColor(CARD_BORDER);
        c.setBorderWidth(0.7f);
        c.setHorizontalAlignment(align);
        c.setVerticalAlignment(com.lowagie.text.Element.ALIGN_MIDDLE);
        tbl.addCell(c);
    }

    private static com.lowagie.text.pdf.PdfPCell statCell(
            String label, String valor,
            java.awt.Color fgColor, java.awt.Color bgColor,
            java.awt.Color borderColor) {
        com.lowagie.text.pdf.PdfPCell c = new com.lowagie.text.pdf.PdfPCell();
        c.setBackgroundColor(bgColor);
        c.setBorderColor(borderColor);
        c.setBorderWidth(1.5f);
        c.setPadding(12);
        c.setVerticalAlignment(com.lowagie.text.Element.ALIGN_MIDDLE);

        com.lowagie.text.Paragraph num = new com.lowagie.text.Paragraph(
                valor, font(18, com.lowagie.text.Font.BOLD, fgColor));
        num.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        c.addElement(num);

        com.lowagie.text.Paragraph lbl = new com.lowagie.text.Paragraph(
                label, font(8, com.lowagie.text.Font.BOLD, fgColor));
        lbl.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        c.addElement(lbl);
        return c;
    }

    private static String formatPrecio(double v) {
        return String.format("$%,.0f", v);
    }
}
