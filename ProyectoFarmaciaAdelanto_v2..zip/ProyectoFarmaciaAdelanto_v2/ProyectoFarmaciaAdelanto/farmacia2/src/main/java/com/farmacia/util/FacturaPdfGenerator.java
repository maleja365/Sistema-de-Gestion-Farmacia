package com.farmacia.util;

import com.farmacia.model.DetallePedido;
import com.farmacia.model.Pedido;

import java.io.OutputStream;
import java.time.format.DateTimeFormatter;

/**
 * Genera la factura en PDF con el estilo visual de FarmaciApp:
 *   --cian       #0056A8
 *   --verde      #6ADE1D  (rgb 106,222,29)
 *   --verde-dark #288054  (rgb 40,128,84)
 *   --bg         #f0f4f8
 *   --card-shadow suave, bordes redondeados simulados con padding
 *
 * Usa OpenPDF (com.lowagie).
 */
public class FacturaPdfGenerator {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    // ── Paleta FarmaciApp ──────────────────────────────────────────────────────
    private static final java.awt.Color CIAN        = new java.awt.Color(0,   86,  168);   // #0056A8
    private static final java.awt.Color CIAN_DARK   = new java.awt.Color(0,   64,  128);   // #004080
    private static final java.awt.Color VERDE       = new java.awt.Color(106, 222,  29);   // #6ADE1D
    private static final java.awt.Color VERDE_DARK  = new java.awt.Color(40,  128,  84);   // #288054
    private static final java.awt.Color BG          = new java.awt.Color(240, 244, 248);   // #f0f4f8
    private static final java.awt.Color CARD_BORDER = new java.awt.Color(228, 236, 245);   // #e4ecf5
    private static final java.awt.Color BADGE_BG    = new java.awt.Color(230, 241, 251);   // #e6f1fb  (categoria badge)
    private static final java.awt.Color TEXT_DARK   = new java.awt.Color(26,  42,   58);   // #1a2a3a
    private static final java.awt.Color TEXT_GREY   = new java.awt.Color(136, 136, 136);   // #888
    private static final java.awt.Color ROW_ALT     = new java.awt.Color(245, 247, 250);
    private static final java.awt.Color STOCK_GREEN_BG = new java.awt.Color(232, 245, 233); // stock-disponible bg
    private static final java.awt.Color STOCK_GREEN_FG = new java.awt.Color(30,  132,  73);

    // ── Fuentes ────────────────────────────────────────────────────────────────
    // Título principal  → "FarmaciApp" en cian, negrita grande
    private static com.lowagie.text.Font fAppName() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 26,
                com.lowagie.text.Font.BOLD, CIAN);
    }
    // "App" en verde (simulado con Chunk separado)
    private static com.lowagie.text.Font fAppNameAccent() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 26,
                com.lowagie.text.Font.BOLD, VERDE_DARK);
    }
    private static com.lowagie.text.Font fSubtitle() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 10,
                com.lowagie.text.Font.NORMAL, TEXT_GREY);
    }
    // Etiquetas de sección (DATOS DEL CLIENTE, etc.) → cian bold 9px uppercase
    private static com.lowagie.text.Font fSectionLabel() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 9,
                com.lowagie.text.Font.BOLD, CIAN);
    }
    private static com.lowagie.text.Font fNormal() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 10,
                com.lowagie.text.Font.NORMAL, TEXT_DARK);
    }
    private static com.lowagie.text.Font fBold() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 10,
                com.lowagie.text.Font.BOLD, TEXT_DARK);
    }
    // Cabecera de tabla → blanco sobre cian (igual que .btn-agregar / navbar)
    private static com.lowagie.text.Font fTableHeader() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 10,
                com.lowagie.text.Font.BOLD, java.awt.Color.WHITE);
    }
    // Total → verde-dark bold grande (igual que .precio en cian, pero usamos verde para destacar)
    private static com.lowagie.text.Font fTotal() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 14,
                com.lowagie.text.Font.BOLD, VERDE_DARK);
    }
    // Badge categoría → cian pequeño bold
    private static com.lowagie.text.Font fBadge() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 8,
                com.lowagie.text.Font.BOLD, CIAN);
    }
    private static com.lowagie.text.Font fFooter() {
        return new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 9,
                com.lowagie.text.Font.ITALIC, TEXT_GREY);
    }

    // ─────────────────────────────────────────────────────────────────────────
    public static void generar(Pedido pedido, OutputStream out) throws Exception {

        com.lowagie.text.Document doc =
                new com.lowagie.text.Document(com.lowagie.text.PageSize.A4, 36, 36, 36, 36);
        com.lowagie.text.pdf.PdfWriter writer =
                com.lowagie.text.pdf.PdfWriter.getInstance(doc, out);
        doc.open();

        com.lowagie.text.pdf.PdfContentByte canvas = writer.getDirectContentUnder();

        // ── Fondo general (--bg #f0f4f8) ────────────────────────────────────
        canvas.setColorFill(BG);
        canvas.rectangle(0, 0, doc.getPageSize().getWidth(), doc.getPageSize().getHeight());
        canvas.fill();

        // ── Banda superior cian (navbar) ─────────────────────────────────────
        float pageW = doc.getPageSize().getWidth();
        float pageH = doc.getPageSize().getHeight();
        canvas.setColorFill(CIAN);
        canvas.rectangle(0, pageH - 80, pageW, 80);
        canvas.fill();

        // Franja verde delgada debajo del banner (acento)
        canvas.setColorFill(VERDE);
        canvas.rectangle(0, pageH - 84, pageW, 4);
        canvas.fill();

        // ── Logo "Farmaci" + "App" en el banner ──────────────────────────────
        // Usamos un Paragraph posicionado; como OpenPDF no soporta posición absoluta fácil
        // en add(), lo ponemos como primer elemento con fondo transparente sobre el banner.
        com.lowagie.text.Paragraph logo = new com.lowagie.text.Paragraph();
        logo.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        logo.add(new com.lowagie.text.Chunk("Farmaci",
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 24,
                        com.lowagie.text.Font.BOLD, java.awt.Color.WHITE)));
        logo.add(new com.lowagie.text.Chunk("App",
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 24,
                        com.lowagie.text.Font.BOLD, VERDE)));
        logo.add(new com.lowagie.text.Chunk("  —  Tienda",
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 13,
                        com.lowagie.text.Font.NORMAL, new java.awt.Color(255,255,255,180))));
        logo.setSpacingBefore(18);
        logo.setSpacingAfter(4);
        doc.add(logo);

        com.lowagie.text.Paragraph tagline = new com.lowagie.text.Paragraph(
                "Farmacia Adelanto — Tu salud, nuestra prioridad", fSubtitle());
        tagline.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        // Texto blanco semitransparente sobre el banner cian
        ((com.lowagie.text.Font) tagline.getFont()).setColor(new java.awt.Color(255,255,255,190));
        doc.add(tagline);

        espaciado(doc, 22);

        // ── "Card" de info factura (simulada con tabla 1 celda con borde) ────
        com.lowagie.text.pdf.PdfPTable cardFactura = cardContenedor(2);
        // Celda izquierda: número de factura
        com.lowagie.text.Phrase phrFactura = new com.lowagie.text.Phrase();
        phrFactura.add(new com.lowagie.text.Chunk("FACTURA  ", fSectionLabel()));
        phrFactura.add(new com.lowagie.text.Chunk(
                String.format("N° %06d", pedido.getIdPedido()), fBold()));
        com.lowagie.text.pdf.PdfPCell cFac = celdaCard(phrFactura,
                com.lowagie.text.Element.ALIGN_LEFT);
        cardFactura.addCell(cFac);

        // Celda derecha: fecha
        com.lowagie.text.Phrase phrFecha = new com.lowagie.text.Phrase();
        phrFecha.add(new com.lowagie.text.Chunk("Fecha: ", fSectionLabel()));
        phrFecha.add(new com.lowagie.text.Chunk(
                pedido.getFechaPedido().format(FMT), fNormal()));
        com.lowagie.text.pdf.PdfPCell cFecha = celdaCard(phrFecha,
                com.lowagie.text.Element.ALIGN_RIGHT);
        cardFactura.addCell(cFecha);
        doc.add(cardFactura);

        espaciado(doc, 10);

        // ── Card: Datos del cliente ───────────────────────────────────────────
        doc.add(labelSeccion("👤  DATOS DEL CLIENTE"));
        espaciado(doc, 4);

        com.lowagie.text.pdf.PdfPTable cardCliente = cardContenedor(2);

        // Columna izquierda
        com.lowagie.text.pdf.PdfPCell colIzq = new com.lowagie.text.pdf.PdfPCell();
        colIzq.setBorder(0); colIzq.setPaddingLeft(14); colIzq.setPaddingTop(10);
        colIzq.setPaddingBottom(10); colIzq.setBackgroundColor(java.awt.Color.WHITE);
        colIzq.addElement(filaInfo("Cliente",  pedido.getUsuario().getNombre()));
        colIzq.addElement(filaInfo("Usuario",  pedido.getUsuario().getUsuario()));
        cardCliente.addCell(colIzq);

        // Columna derecha
        com.lowagie.text.pdf.PdfPCell colDer = new com.lowagie.text.pdf.PdfPCell();
        colDer.setBorder(0); colDer.setPaddingLeft(8); colDer.setPaddingTop(10);
        colDer.setPaddingBottom(10); colDer.setBackgroundColor(java.awt.Color.WHITE);
        colDer.addElement(filaInfo("Teléfono",  pedido.getTelefono()));
        colDer.addElement(filaInfo("Dirección", pedido.getDireccion()));
        if (pedido.getNotas() != null && !pedido.getNotas().isBlank()) {
            colDer.addElement(filaInfo("Notas", pedido.getNotas()));
        }
        cardCliente.addCell(colDer);
        doc.add(cardCliente);

        espaciado(doc, 10);

        // ── Badge método de pago ─────────────────────────────────────────────
        String metodoDisplay = switch (pedido.getMetodoPago()) {
            case "EFECTIVO" -> "Efectivo";
            case "NEQUI"    -> "Nequi";
            case "TARJETA"  -> "Tarjeta";
            default         -> pedido.getMetodoPago();
        };
        String iconoPago = switch (pedido.getMetodoPago()) {
            case "EFECTIVO" -> "💵";
            case "NEQUI"    -> "📱";
            case "TARJETA"  -> "💳";
            default         -> "💰";
        };

        // Mini-card para método de pago (similar al badge de categoría del HTML)
        com.lowagie.text.pdf.PdfPTable cardPago = cardContenedor(1);
        com.lowagie.text.Phrase phrPago = new com.lowagie.text.Phrase();
        phrPago.add(new com.lowagie.text.Chunk("MÉTODO DE PAGO   ", fSectionLabel()));
        phrPago.add(new com.lowagie.text.Chunk(iconoPago + "  " + metodoDisplay, fBold()));
        com.lowagie.text.pdf.PdfPCell cPago = celdaCard(phrPago,
                com.lowagie.text.Element.ALIGN_LEFT);
        cPago.setBackgroundColor(BADGE_BG);  // azul claro, igual que .categoria badge
        cardPago.addCell(cPago);
        doc.add(cardPago);

        espaciado(doc, 12);

        // ── Tabla de productos ───────────────────────────────────────────────
        doc.add(labelSeccion("🛒  DETALLE DE PRODUCTOS"));
        espaciado(doc, 6);

        float[] widths = {48f, 14f, 19f, 19f};
        com.lowagie.text.pdf.PdfPTable tabla =
                new com.lowagie.text.pdf.PdfPTable(widths);
        tabla.setWidthPercentage(100);

        // Cabecera de tabla → fondo cian, texto blanco (igual que .btn-agregar / navbar)
        String[] headers = {"Producto", "Cant.", "Precio Unit.", "Subtotal"};
        for (String h : headers) {
            com.lowagie.text.pdf.PdfPCell cell =
                    new com.lowagie.text.pdf.PdfPCell(
                            new com.lowagie.text.Phrase(h, fTableHeader()));
            cell.setBackgroundColor(CIAN);
            cell.setPadding(8);
            cell.setBorder(0);
            tabla.addCell(cell);
        }

        // Filas alternadas (blanco / --bg row alt)
        boolean alt = false;
        for (DetallePedido d : pedido.getDetalles()) {
            java.awt.Color bg = alt ? ROW_ALT : java.awt.Color.WHITE;
            agregarCelda(tabla, d.getNombreProducto(), fNormal(), bg,
                    com.lowagie.text.Element.ALIGN_LEFT);
            agregarCelda(tabla, String.valueOf(d.getCantidad()), fNormal(), bg,
                    com.lowagie.text.Element.ALIGN_CENTER);
            agregarCelda(tabla, formatPrecio(d.getPrecioUnitario()), fNormal(), bg,
                    com.lowagie.text.Element.ALIGN_RIGHT);
            // Subtotal con color cian (igual que .precio en las cards)
            com.lowagie.text.Font fPrecio = new com.lowagie.text.Font(
                    com.lowagie.text.Font.HELVETICA, 10,
                    com.lowagie.text.Font.BOLD, CIAN);
            agregarCelda(tabla, formatPrecio(d.getSubtotal()), fPrecio, bg,
                    com.lowagie.text.Element.ALIGN_RIGHT);
            alt = !alt;
        }
        doc.add(tabla);

        espaciado(doc, 10);

        // ── Card total (similar a card-footer con .precio grande) ────────────
        com.lowagie.text.pdf.PdfPTable cardTotal = cardContenedor(2);

        // Celda izquierda: badge stock-disponible (verde) → "✓ Pago confirmado"
        com.lowagie.text.Phrase phrStock = new com.lowagie.text.Phrase();
        phrStock.add(new com.lowagie.text.Chunk("✓  Pago confirmado",
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 9,
                        com.lowagie.text.Font.BOLD, STOCK_GREEN_FG)));
        com.lowagie.text.pdf.PdfPCell cStock = celdaCard(phrStock,
                com.lowagie.text.Element.ALIGN_LEFT);
        cStock.setBackgroundColor(STOCK_GREEN_BG);
        cardTotal.addCell(cStock);

        // Celda derecha: total en verde-dark bold (igual que .precio → aquí lo usamos grande)
        com.lowagie.text.Phrase phrTotal = new com.lowagie.text.Phrase();
        phrTotal.add(new com.lowagie.text.Chunk("TOTAL A PAGAR   ", fSectionLabel()));
        phrTotal.add(new com.lowagie.text.Chunk(formatPrecio(pedido.getTotal()), fTotal()));
        com.lowagie.text.pdf.PdfPCell cTotal = celdaCard(phrTotal,
                com.lowagie.text.Element.ALIGN_RIGHT);
        cTotal.setBackgroundColor(java.awt.Color.WHITE);
        cardTotal.addCell(cTotal);
        doc.add(cardTotal);

        espaciado(doc, 16);

        // ── Separador cian (igual que LineSeparator del original) ────────────
        com.lowagie.text.pdf.draw.LineSeparator sep =
                new com.lowagie.text.pdf.draw.LineSeparator(
                        1.5f, 100f, CIAN,
                        com.lowagie.text.Element.ALIGN_CENTER, -2);
        doc.add(new com.lowagie.text.Chunk(sep));
        espaciado(doc, 8);

        // Franja verde delgada de cierre
        com.lowagie.text.pdf.draw.LineSeparator sepVerde =
                new com.lowagie.text.pdf.draw.LineSeparator(
                        3f, 100f, VERDE,
                        com.lowagie.text.Element.ALIGN_CENTER, -2);
        doc.add(new com.lowagie.text.Chunk(sepVerde));
        espaciado(doc, 8);

        // ── Footer ────────────────────────────────────────────────────────────
        com.lowagie.text.Paragraph footer = new com.lowagie.text.Paragraph(
                "¡Gracias por tu compra en FarmaciApp! — Conserva este documento como comprobante.",
                fFooter());
        footer.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
        doc.add(footer);

        doc.close();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Espaciado vertical vacío */
    private static void espaciado(com.lowagie.text.Document doc, float pts) throws Exception {
        com.lowagie.text.Paragraph sp = new com.lowagie.text.Paragraph(" ");
        sp.setSpacingAfter(pts);
        doc.add(sp);
    }

    /** Etiqueta de sección estilo .categoria badge del HTML */
    private static com.lowagie.text.Paragraph labelSeccion(String texto) {
        com.lowagie.text.Font f = new com.lowagie.text.Font(
                com.lowagie.text.Font.HELVETICA, 9,
                com.lowagie.text.Font.BOLD, CIAN);
        com.lowagie.text.Paragraph p = new com.lowagie.text.Paragraph(texto, f);
        p.setSpacingBefore(2);
        return p;
    }

    /**
     * Tabla de 1 fila que simula una .producto-card:
     * fondo blanco, borde 1.5px #e4ecf5, box-shadow simulado con color del borde.
     */
    private static com.lowagie.text.pdf.PdfPTable cardContenedor(int cols) throws Exception {
        com.lowagie.text.pdf.PdfPTable t =
                new com.lowagie.text.pdf.PdfPTable(cols);
        t.setWidthPercentage(100);
        t.setSpacingBefore(0);
        t.setSpacingAfter(0);
        return t;
    }

    /** Celda con estilo de card (fondo blanco, borde card-border, padding generoso) */
    private static com.lowagie.text.pdf.PdfPCell celdaCard(
            com.lowagie.text.Phrase contenido, int align) {
        com.lowagie.text.pdf.PdfPCell cell =
                new com.lowagie.text.pdf.PdfPCell(contenido);
        cell.setBackgroundColor(java.awt.Color.WHITE);
        cell.setBorderColor(CARD_BORDER);
        cell.setBorderWidth(1.5f);
        cell.setPadding(11);
        cell.setHorizontalAlignment(align);
        cell.setVerticalAlignment(com.lowagie.text.Element.ALIGN_MIDDLE);
        return cell;
    }

    /** Par "Label: valor" para las filas de datos del cliente */
    private static com.lowagie.text.Paragraph filaInfo(String label, String valor) {
        com.lowagie.text.Paragraph p = new com.lowagie.text.Paragraph();
        p.add(new com.lowagie.text.Chunk(label + ":  ",
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 9,
                        com.lowagie.text.Font.BOLD, CIAN)));
        p.add(new com.lowagie.text.Chunk(valor == null ? "—" : valor,
                new com.lowagie.text.Font(com.lowagie.text.Font.HELVETICA, 10,
                        com.lowagie.text.Font.NORMAL, TEXT_DARK)));
        p.setSpacingAfter(3);
        return p;
    }

    /** Celda de tabla de productos */
    private static void agregarCelda(com.lowagie.text.pdf.PdfPTable tabla,
                                     String texto,
                                     com.lowagie.text.Font font,
                                     java.awt.Color bg,
                                     int align) {
        com.lowagie.text.pdf.PdfPCell cell =
                new com.lowagie.text.pdf.PdfPCell(
                        new com.lowagie.text.Phrase(texto, font));
        cell.setBackgroundColor(bg);
        cell.setPadding(7);
        cell.setBorderColor(CARD_BORDER);
        cell.setBorderWidth(0.8f);
        cell.setHorizontalAlignment(align);
        cell.setVerticalAlignment(com.lowagie.text.Element.ALIGN_MIDDLE);
        tabla.addCell(cell);
    }

    private static String formatPrecio(double valor) {
        return String.format("$%,.0f", valor);
    }
}